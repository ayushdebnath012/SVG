from __future__ import annotations

import io
import unittest
from dataclasses import replace
from pathlib import Path
from unittest import mock

import numpy as np
from PIL import Image

from svgpatchlab.architectures.semantic import (
    SemanticIdPatchArchitecture,
    _selected_targets,
)
from svgpatchlab.architectures.factory import create_architecture
from svgpatchlab.core import build_scene
from svgpatchlab.eval.render import SVGIDMap, SVGVisualContext
from svgpatchlab.models.base import ModelAdapter
from svgpatchlab.types import BenchmarkCase, ModelRequest, ModelResponse


SOURCE_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">'
    "<g>"
    '<rect x="0" y="0" width="10" height="10" fill="#ff0000"/>'
    '<circle cx="15" cy="15" r="4" fill="#0000ff"/>'
    "</g>"
    "</svg>"
)

ANSWER_WITHOUT_RECT = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">'
    "<g>"
    '<circle cx="15" cy="15" r="4" fill="#0000ff"/>'
    "</g>"
    "</svg>"
)


def _png(color: tuple[int, int, int, int]) -> bytes:
    image = Image.new("RGBA", (8, 8), color)
    output = io.BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def _visual_context() -> SVGVisualContext:
    normal_png = _png((255, 0, 0, 255))
    id_png = _png((0x3C, 0x6E, 0xF2, 255))
    normal_rgba = np.asarray(
        Image.open(io.BytesIO(normal_png)).convert("RGBA"), dtype=np.uint8
    )
    id_rgba = np.asarray(
        Image.open(io.BytesIO(id_png)).convert("RGBA"), dtype=np.uint8
    )
    labels = np.zeros((8, 8), dtype=np.int32)
    id_map = SVGIDMap(
        png=id_png,
        rgb=id_rgba[:, :, :3],
        labels=labels,
        node_colors={"n2": "#3c6ef2", "n3": "#daa66b"},
        color_nodes={"#3c6ef2": "n2", "#daa66b": "n3"},
        leaf_node_ids=("n2", "n3"),
        size=8,
    )
    return SVGVisualContext(
        normal_png=normal_png,
        normal_rgba=normal_rgba,
        id_map=id_map,
        stats={
            "n0": {
                "bbox": [0, 0, 20, 20],
                "area_pct": 100,
                "position": "center",
                "color": "#ff0000",
            },
            "n1": {
                "bbox": [0, 0, 20, 20],
                "area_pct": 100,
                "position": "center",
                "color": "#ff0000",
            },
            "n2": {
                "bbox": [0, 0, 10, 10],
                "area_pct": 25,
                "position": "top-left",
                "color": "#ff0000",
                "id_color": "#3c6ef2",
            },
            "n3": {
                "bbox": [11, 11, 8, 8],
                "area_pct": 12.5,
                "position": "bottom-right",
                "color": "#0000ff",
                "id_color": "#daa66b",
            },
        },
        method="id_buffer",
    )


def _case(task: str = "delete") -> BenchmarkCase:
    return BenchmarkCase(
        task=task,
        emoji_id="synthetic",
        instruction="Remove the red square.",
        source_svg=SOURCE_SVG,
        answer_svg=ANSWER_WITHOUT_RECT,
        query_path=Path("."),
        answer_path=Path("."),
    )


class SequenceModel(ModelAdapter):
    def __init__(self, responses: list[str], *, supports_images: bool):
        self.responses = list(responses)
        self.supports_images = supports_images
        self.requests: list[ModelRequest] = []

    def generate(self, request: ModelRequest) -> ModelResponse:
        self.requests.append(request)
        return ModelResponse(self.responses.pop(0))


class TargetSelectionTests(unittest.TestCase):
    def test_deduplicates_caps_and_keeps_first_ranked_related_node(self):
        scene = build_scene(SOURCE_SVG)
        targets = _selected_targets(
            '{"targets":["n2","n2","n1","n3"]}',
            scene,
            2,
            forbid_root=True,
        )
        self.assertEqual(targets, ("n2", "n3"))

    def test_unknown_target_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "unknown IDs"):
            _selected_targets(
                '{"targets":["n99"]}',
                build_scene(SOURCE_SVG),
                3,
                forbid_root=True,
            )

    def test_delete_cannot_select_root(self):
        with self.assertRaisesRegex(ValueError, "SVG root"):
            _selected_targets(
                '{"targets":["n0"]}',
                build_scene(SOURCE_SVG),
                3,
                forbid_root=True,
            )


class SemanticArchitectureTests(unittest.TestCase):
    def test_architecture_is_registered_with_configurable_limits(self):
        architecture = create_architecture(
            "semantic_id_patch",
            render_size=96,
            max_candidates=2,
        )
        self.assertIsInstance(architecture, SemanticIdPatchArchitecture)
        self.assertEqual(architecture.render_size, 96)
        self.assertEqual(architecture.max_candidates, 2)

    def _run(self, model: SequenceModel):
        architecture = SemanticIdPatchArchitecture(render_size=64, max_candidates=3)
        preview_png = _png((0, 0, 255, 255))
        with mock.patch.object(
            architecture,
            "_visual_context",
            return_value=_visual_context(),
        ), mock.patch(
            "svgpatchlab.architectures.semantic.render_svg_png",
            return_value=preview_png,
        ) as render_preview:
            result = architecture.run(_case(), model)
        return result, render_preview

    def test_multimodal_flow_uses_id_pair_then_only_shortlisted_preview(self):
        model = SequenceModel(
            [
                '{"targets":["n2"]}',
                '{"version":2,"operations":[{"op":"remove_element","targets":["n2"]}]}',
            ],
            supports_images=True,
        )
        result, render_preview = self._run(model)

        self.assertIsNone(result.error)
        self.assertIsNotNone(result.output_svg)
        self.assertEqual(result.model_calls, 2)
        self.assertEqual(render_preview.call_count, 1)
        hidden_svg = render_preview.call_args.args[0]
        self.assertIn("display:none", hidden_svg)

        self.assertEqual(len(model.requests), 2)
        self.assertEqual(len(model.requests[0].images), 2)
        self.assertEqual(len(model.requests[1].images), 2)
        self.assertIn('"id_color": "#3c6ef2"', model.requests[0].prompt)
        self.assertIn('"shortlisted_targets": [', model.requests[1].prompt)
        self.assertIn('"target": "n2"', model.requests[1].prompt)
        self.assertIn('"kind": "without_candidate"', model.requests[1].prompt)

    def test_text_only_model_gets_numeric_visual_context_without_images(self):
        model = SequenceModel(
            [
                '{"targets":["n2"]}',
                '{"version":2,"operations":[{"op":"remove_element","targets":["n2"]}]}',
            ],
            supports_images=False,
        )
        result, _ = self._run(model)

        self.assertIsNone(result.error)
        self.assertEqual(model.requests[0].images, ())
        self.assertEqual(model.requests[1].images, ())
        self.assertIn("No images are attached", model.requests[0].prompt)
        self.assertIn("changed_area_pct", model.requests[1].prompt)
        self.assertIn("transparent_hole_area_pct", model.requests[1].prompt)

    def test_complex_svg_still_gives_vision_model_the_normal_render(self):
        model = SequenceModel(
            [
                '{"targets":["n2"]}',
                '{"version":2,"operations":[{"op":"remove_element","targets":["n2"]}]}',
            ],
            supports_images=True,
        )
        architecture = SemanticIdPatchArchitecture(render_size=64)
        fallback = replace(
            _visual_context(),
            id_map=None,
            method="counterfactual",
            unsupported_features=("n2:<rect> filter",),
        )
        with mock.patch.object(
            architecture,
            "_visual_context",
            return_value=fallback,
        ), mock.patch(
            "svgpatchlab.architectures.semantic.render_svg_png",
            return_value=_png((0, 0, 255, 255)),
        ):
            result = architecture.run(_case(), model)

        self.assertIsNone(result.error)
        self.assertEqual(len(model.requests[0].images), 1)
        self.assertIn("ID image could not be produced", model.requests[0].prompt)

    def test_final_patch_cannot_escape_shortlist(self):
        model = SequenceModel(
            [
                '{"targets":["n2"]}',
                '{"version":2,"operations":[{"op":"remove_element","targets":["n3"]}]}',
            ],
            supports_images=False,
        )
        result, _ = self._run(model)

        self.assertIsNone(result.output_svg)
        self.assertIn("not shortlisted: n3", result.error)
        self.assertEqual(result.model_calls, 2)

    def test_bad_stage_one_stops_before_preview_and_second_call(self):
        model = SequenceModel(
            ['{"targets":["n99"]}'],
            supports_images=False,
        )
        result, render_preview = self._run(model)

        self.assertIsNone(result.output_svg)
        self.assertIn("unknown IDs", result.error)
        self.assertEqual(result.model_calls, 1)
        self.assertEqual(render_preview.call_count, 0)
        self.assertEqual(len(model.requests), 1)


if __name__ == "__main__":
    unittest.main()
