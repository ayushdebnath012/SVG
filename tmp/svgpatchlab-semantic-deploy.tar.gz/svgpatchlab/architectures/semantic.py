from __future__ import annotations

import base64
import io
import json
from functools import lru_cache
from typing import Any

from svgpatchlab.core import PatchPolicy, apply_patch, build_scene, parse_patch, validate_patch
from svgpatchlab.core.patch import PatchError, extract_json_object
from svgpatchlab.core.xml import index_tree, parse_svg, serialize_svg
from svgpatchlab.eval.render import render_svg_png, render_svg_visual_context
from svgpatchlab.models import ModelAdapter
from svgpatchlab.types import ArchitectureResult, BenchmarkCase, ModelRequest

from .base import Architecture
from .prompts import patch_prompt, target_selection_prompt


def _png_data_url(png: bytes) -> str:
    encoded = base64.b64encode(png).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def _selected_targets(
    response_text: str,
    scene: dict[str, Any],
    max_candidates: int,
    *,
    forbid_root: bool,
) -> tuple[str, ...]:
    payload = extract_json_object(response_text)
    raw_targets = payload.get("targets")
    if not isinstance(raw_targets, list) or not raw_targets:
        raise PatchError("target selection requires a nonempty 'targets' list")
    if not all(isinstance(item, str) for item in raw_targets):
        raise PatchError("selected targets must be node ID strings")

    nodes = {node["id"]: node for node in scene["nodes"]}
    unknown = sorted(set(raw_targets) - set(nodes))
    if unknown:
        raise PatchError(f"target selection contains unknown IDs: {', '.join(unknown)}")

    root_id = scene["root_id"]
    if forbid_root and root_id in raw_targets:
        raise PatchError("element removal cannot select the SVG root")

    parents = {node_id: node.get("parent") for node_id, node in nodes.items()}

    def ancestors(node_id: str) -> set[str]:
        result: set[str] = set()
        current = parents.get(node_id)
        while current is not None:
            result.add(current)
            current = parents.get(current)
        return result

    # Preserve model ranking while discarding duplicates and contradictory
    # ancestor/descendant alternatives. The first-ranked target wins.
    selected: list[str] = []
    for target in raw_targets:
        if target in selected:
            continue
        target_ancestors = ancestors(target)
        if any(
            existing in target_ancestors or target in ancestors(existing)
            for existing in selected
        ):
            continue
        selected.append(target)
        if len(selected) >= max_candidates:
            break

    if not selected:
        raise PatchError("target selection did not contain a usable node ID")
    return tuple(selected)


def _hide_node(svg: str, node_id: str) -> str:
    root = parse_svg(svg)
    by_id = {node.node_id: node.element for node in index_tree(root)}
    if node_id not in by_id:
        raise PatchError(f"cannot preview unknown node: {node_id}")
    element = by_id[node_id]
    prior = element.attrib.get("style")
    element.attrib["style"] = (f"{prior};" if prior else "") + "display:none"
    return serialize_svg(root)


def _counterfactual_summary(original_png: bytes, hidden_png: bytes) -> dict[str, Any]:
    try:
        import numpy as np
        from PIL import Image
    except ImportError as exc:  # pragma: no cover - renderer dependency guard
        raise RuntimeError("counterfactual summaries require numpy and Pillow") from exc

    original = np.asarray(
        Image.open(io.BytesIO(original_png)).convert("RGBA"), dtype=np.float32
    ) / 255.0
    hidden = np.asarray(
        Image.open(io.BytesIO(hidden_png)).convert("RGBA"), dtype=np.float32
    ) / 255.0
    if original.shape != hidden.shape:
        raise RuntimeError("counterfactual preview size differs from the original render")

    changed = np.abs(original - hidden).max(axis=2) > 0.02
    if not changed.any():
        return {
            "changed": False,
            "changed_area_pct": 0.0,
            "transparent_hole_area_pct": 0.0,
            "revealed_or_repainted_area_pct": 0.0,
        }

    height, width = changed.shape
    rows = np.any(changed, axis=1).nonzero()[0]
    columns = np.any(changed, axis=0).nonzero()[0]
    original_alpha = original[:, :, 3]
    hidden_alpha = hidden[:, :, 3]
    holes = changed & (original_alpha > 0.05) & (hidden_alpha <= 0.05)
    revealed = changed & (hidden_alpha > 0.05)

    return {
        "changed": True,
        "changed_area_pct": round(100.0 * float(changed.sum()) / changed.size, 3),
        "pixel_bbox": [
            int(columns[0]),
            int(rows[0]),
            int(columns[-1] - columns[0] + 1),
            int(rows[-1] - rows[0] + 1),
        ],
        "render_size": [width, height],
        "transparent_hole_area_pct": round(
            100.0 * float(holes.sum()) / changed.size, 3
        ),
        "revealed_or_repainted_area_pct": round(
            100.0 * float(revealed.sum()) / changed.size, 3
        ),
    }


class SemanticIdPatchArchitecture(Architecture):
    """Two-stage patching grounded by a rendered element ownership buffer.

    Stage one ranks at most `max_candidates` DOM nodes using the compact scene
    plus a normal/ID render pair when the model supports images. Only those
    candidates are then hidden and rerendered. Stage two sees the previews and
    emits the ordinary validated patch. The final patch may address only the
    shortlisted nodes.
    """

    name = "semantic_id_patch"
    requires_renderer = True

    def __init__(
        self,
        render_size: int = 192,
        max_candidates: int = 3,
        allow_counterfactual_fallback: bool = True,
        policy: PatchPolicy | None = None,
    ):
        if render_size < 32:
            raise ValueError("render_size must be at least 32")
        if not 1 <= max_candidates <= 8:
            raise ValueError("max_candidates must be between 1 and 8")
        self.render_size = int(render_size)
        self.max_candidates = int(max_candidates)
        self.allow_counterfactual_fallback = bool(allow_counterfactual_fallback)
        self.policy = policy or PatchPolicy()

    @lru_cache(maxsize=128)
    def _visual_context(self, svg: str):
        return render_svg_visual_context(
            svg,
            size=self.render_size,
            fallback=self.allow_counterfactual_fallback,
        )

    def run(self, case: BenchmarkCase, model: ModelAdapter) -> ArchitectureResult:
        result = ArchitectureResult()
        try:
            visual_context = self._visual_context(case.source_svg)
            scene = build_scene(case.source_svg, visual_stats=visual_context.stats)
            scene_text = json.dumps(scene, indent=2, sort_keys=True)

            can_show_images = bool(model.supports_images)
            can_show_id_map = bool(
                model.supports_images and visual_context.id_map is not None
            )
            selection_images = (
                (
                    visual_context.normal_data_url,
                    visual_context.id_data_url,
                )
                if can_show_id_map
                else (
                    (visual_context.normal_data_url,)
                    if can_show_images
                    else ()
                )
            )
            # The type checker cannot infer that id_data_url is non-None from
            # the id_map test above; filter defensively at the API boundary.
            selection_images = tuple(
                image for image in selection_images if image is not None
            )

            selection_request = ModelRequest(
                target_selection_prompt(
                    case.instruction,
                    scene_text,
                    max_candidates=self.max_candidates,
                    has_images=can_show_images,
                    has_id_map=can_show_id_map,
                ),
                images=selection_images,
                metadata={
                    "request_id": f"{case.case_id}:semantic-select",
                    "visual_context_method": visual_context.method,
                },
            )
            result.model_calls += 1
            selection_response = model.generate(selection_request)
            result.raw_responses.append(selection_response.text)
            targets = _selected_targets(
                selection_response.text,
                scene,
                self.max_candidates,
                forbid_root=case.task == "delete",
            )

            preview_records: list[dict[str, Any]] = []
            preview_urls: list[str] = []
            for target in targets:
                hidden_svg = _hide_node(case.source_svg, target)
                hidden_png = render_svg_png(
                    hidden_svg,
                    size=self.render_size,
                    background=None,
                )
                record: dict[str, Any] = {
                    "target": target,
                    "difference": _counterfactual_summary(
                        visual_context.normal_png,
                        hidden_png,
                    ),
                }
                if model.supports_images:
                    # Stage-two image 1 is always the original.
                    record["image_index"] = len(preview_urls) + 2
                    preview_urls.append(_png_data_url(hidden_png))
                preview_records.append(record)

            image_order: list[dict[str, Any]] = []
            patch_images: tuple[str, ...] = ()
            if model.supports_images:
                image_order.append({"index": 1, "kind": "original"})
                image_order.extend(
                    {
                        "index": record["image_index"],
                        "kind": "without_candidate",
                        "target": record["target"],
                    }
                    for record in preview_records
                )
                patch_images = (
                    visual_context.normal_data_url,
                    *preview_urls,
                )

            final_context = {
                "scene": scene,
                "shortlisted_targets": list(targets),
                "visual_context": {
                    "method": visual_context.method,
                    "unsupported_features": list(
                        visual_context.unsupported_features
                    ),
                },
                "counterfactual_previews": preview_records,
                "image_order": image_order,
                "selection_constraint": (
                    "Every final patch target must be one of shortlisted_targets."
                ),
            }
            patch_request = ModelRequest(
                patch_prompt(
                    case.instruction,
                    "ID-grounded target shortlist and hide-and-rerender checks",
                    json.dumps(final_context, indent=2, sort_keys=True),
                ),
                images=patch_images,
                metadata={"request_id": f"{case.case_id}:semantic-patch"},
            )
            result.model_calls += 1
            patch_response = model.generate(patch_request)
            result.raw_responses.append(patch_response.text)
            result.patch = parse_patch(patch_response.text)

            allowed_targets = set(targets)
            final_targets = {
                target
                for operation in result.patch.operations
                for target in operation.targets
            }
            outside = sorted(final_targets - allowed_targets)
            if outside:
                raise PatchError(
                    "final patch targets were not shortlisted: "
                    + ", ".join(outside)
                )

            validate_patch(result.patch, scene, self.policy, task=case.task)
            result.output_svg = apply_patch(case.source_svg, result.patch)
        except Exception as exc:
            result.error = f"{type(exc).__name__}: {exc}"
        return result
