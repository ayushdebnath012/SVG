from __future__ import annotations

from typing import Any

from .base import Architecture
from .diagnostic import OraclePatchArchitecture, OracleTargetArchitecture, TwoStagePatchArchitecture
from .patching import (
    FullContextPatchArchitecture,
    SkeletonPatchArchitecture,
    VisualGNNPatchArchitecture,
    VisualSkeletonPatchArchitecture,
    VisualStatsPatchArchitecture,
)
from .rewrite import FullRewriteArchitecture
from .rules import RuleBasedPatchArchitecture
from .semantic import SemanticIdPatchArchitecture


ARCHITECTURES: dict[str, type[Architecture]] = {
    "oracle_patch": OraclePatchArchitecture,
    "rule_based_patch": RuleBasedPatchArchitecture,
    "full_rewrite": FullRewriteArchitecture,
    "full_context_patch": FullContextPatchArchitecture,
    "skeleton_patch": SkeletonPatchArchitecture,
    "visual_skeleton_patch": VisualSkeletonPatchArchitecture,
    "visual_stats_patch": VisualStatsPatchArchitecture,
    "visual_gnn_patch": VisualGNNPatchArchitecture,
    "semantic_id_patch": SemanticIdPatchArchitecture,
    "oracle_target_patch": OracleTargetArchitecture,
    "two_stage_patch": TwoStagePatchArchitecture,
}


def create_architecture(name: str, **options: Any) -> Architecture:
    try:
        architecture_type = ARCHITECTURES[name]
    except KeyError as exc:
        raise ValueError(f"unknown architecture: {name}") from exc
    return architecture_type(**options)
